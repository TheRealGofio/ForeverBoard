--[[
    ForeverBoard - UI
    Interfaz moderna estilo Discord Soundboard:
    - Rejilla adaptativa multi-columna (Dynamic Grid)
    - Botones tipo tarjeta (Tiles) con icono de WoW y estrella integrada
    - Cabecera estilizada con búsqueda y pestañas
    - Panel de Eventos organizado en tarjetas limpias
    - Menú desplegable flotante con scroll
]]

ForeverBoard = ForeverBoard or {}
local FB = ForeverBoard

local mainFrame = nil
local searchBox = nil
local soundTiles = {}
local contentFrame = nil
local scrollFrame = nil
local triggerContent = nil
local muteBtn = nil
local channelBtn = nil
local combatCheck = nil
local countLabel = nil
local currentTab = "ALL" -- "ALL", "FAV", o "TRIGGERS"
local tabAllBtn = nil
local tabFavBtn = nil
local tabTrigBtn = nil

-- Canales de audio soportados por WoW
local SOUND_CHANNELS = { "Master", "SFX", "Ambience" }

local function L(key)
    return (FB.L and FB.L[key]) or key
end

-- Función auxiliar para trim compatible con todas las versiones de WoW
local function strTrim(s)
    if not s then return "" end
    return s:match("^%s*(.-)%s*$") or ""
end

-- Asigna un icono temático de WoW según el nombre o id del clip
local function GetSoundIcon(sound)
    local s = (sound.id .. " " .. sound.name):lower()
    if s:find("mario") or s:find("muerte") or s:find("death") or s:find("roblox") then
        return "Interface\\Icons\\Ability_Creature_Cursed_02"
    elseif s:find("fanfare") or s:find("victory") or s:find("ff") then
        return "Interface\\Icons\\Spell_Holy_PrayerOfFortitude"
    elseif s:find("butano") or s:find("fire") or s:find("sol") then
        return "Interface\\Icons\\Spell_Fire_FlameBlades"
    elseif s:find("meow") or s:find("cat") or s:find("gato") then
        return "Interface\\Icons\\Ability_Druid_CatForm"
    elseif s:find("anime") or s:find("gemido") or s:find("rizz") then
        return "Interface\\Icons\\Spell_Shadow_Charm"
    elseif s:find("violin") or s:find("sad") or s:find("wipe") then
        return "Interface\\Icons\\Spell_Shadow_Haunting"
    elseif s:find("guapo") or s:find("faaah") or s:find("cheer") then
        return "Interface\\Icons\\Spell_Holy_AuraMastery"
    elseif s:find("horn") or s:find("bocina") then
        return "Interface\\Icons\\INV_Misc_Horn_01"
    else
        return "Interface\\Icons\\INV_Misc_Bell_01"
    end
end

-- Actualiza el aspecto visual del botón de Mute
function FB:UpdateMuteVisuals()
    local isMuted = ForeverBoardDB and ForeverBoardDB.isMuted
    if muteBtn then
        if isMuted then
            muteBtn:SetText(L("MUTE_BTN_MUTED"))
        else
            muteBtn:SetText(L("MUTE_BTN_ON"))
        end
    end
end

-- Actualiza el aspecto visual del botón de canal de audio
function FB:UpdateChannelVisuals()
    if channelBtn and ForeverBoardDB then
        local ch = ForeverBoardDB.soundChannel or "Master"
        channelBtn:SetText(string.format(L("CHANNEL_BTN"), ch))
    end
end

-- Cicla al siguiente canal de audio
function FB:CycleSoundChannel()
    if not ForeverBoardDB then return end
    local current = ForeverBoardDB.soundChannel or "Master"
    local nextCh = "Master"
    for i, ch in ipairs(SOUND_CHANNELS) do
        if ch == current then
            nextCh = SOUND_CHANNELS[(i % #SOUND_CHANNELS) + 1]
            break
        end
    end
    ForeverBoardDB.soundChannel = nextCh
    self:UpdateChannelVisuals()
    print(string.format(L("CHANNEL_CHANGED"), nextCh))
end

-- Comprueba si un sonido está en favoritos
function FB:IsFavorite(soundId)
    if not ForeverBoardDB or not ForeverBoardDB.favorites then
        return false
    end
    return ForeverBoardDB.favorites[soundId] == true
end

-- Alterna el estado de favorito de un sonido
function FB:ToggleFavorite(soundId)
    if not ForeverBoardDB then return end
    ForeverBoardDB.favorites = ForeverBoardDB.favorites or {}
    ForeverBoardDB.favorites[soundId] = not ForeverBoardDB.favorites[soundId]
    self:RefreshSoundList()
end

-- Obtiene el nombre visual de un sonido dado su ID
function FB:GetSoundDisplayName(soundId, triggerType)
    if not soundId or soundId == "" then
        local defId = self:GetDefaultTriggerSound(triggerType)
        local defName = (defId and self.soundMap and self.soundMap[defId] and self.soundMap[defId].name)
        if defName then
            return string.format(L("DEFAULT_FIRST"), defName)
        else
            return L("NONE_SELECTED")
        end
    end
    local sound = self.soundMap and self.soundMap[soundId]
    return sound and sound.name or soundId
end

-- ==========================================================
-- Menú desplegable flotante con scroll
-- ==========================================================
local dropDownMenu = nil
local activeDropKey = nil
local activeDropOwner = nil

function FB:CreateDropDownMenu()
    if dropDownMenu then return dropDownMenu end

    dropDownMenu = CreateFrame("Frame", "ForeverBoardDropDown", UIParent)
    dropDownMenu:SetSize(180, 190)
    dropDownMenu:SetFrameStrata("DIALOG")
    dropDownMenu:SetClampedToScreen(true)
    dropDownMenu:EnableMouse(true)

    if dropDownMenu.SetBackdrop then
        dropDownMenu:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 16, edgeSize = 12,
            insets = { left = 3, right = 3, top = 3, bottom = 3 }
        })
    else
        local bg = dropDownMenu:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints(true)
        bg:SetColorTexture(0.05, 0.05, 0.08, 0.98)
    end

    local dScroll = CreateFrame("ScrollFrame", "ForeverBoardDropScroll", dropDownMenu, "UIPanelScrollFrameTemplate")
    dScroll:SetPoint("TOPLEFT", dropDownMenu, "TOPLEFT", 6, -6)
    dScroll:SetPoint("BOTTOMRIGHT", dropDownMenu, "BOTTOMRIGHT", -22, 6)

    local dContent = CreateFrame("Frame", nil, dScroll)
    dContent:SetSize(150, 1)
    dScroll:SetScrollChild(dContent)

    dropDownMenu.content = dContent
    dropDownMenu.buttons = {}
    dropDownMenu:Hide()

    return dropDownMenu
end

function FB:OpenSoundDropDown(ownerButton, dbKey, triggerType)
    local menu = self:CreateDropDownMenu()
    if menu:IsShown() and activeDropKey == dbKey then
        menu:Hide()
        return
    end

    activeDropKey = dbKey
    activeDropOwner = ownerButton

    menu:ClearAllPoints()
    menu:SetPoint("TOPLEFT", ownerButton, "BOTTOMLEFT", 0, -2)

    local sounds = ForeverBoard_Sounds or {}
    local dContent = menu.content

    local options = {}
    local defaultLabel = FB:GetSoundDisplayName("", triggerType)
    table.insert(options, { id = "", name = defaultLabel })
    for _, s in ipairs(sounds) do
        table.insert(options, { id = s.id, name = s.name })
    end

    local itemHeight = 20
    local yPos = -2

    for i, opt in ipairs(options) do
        local btn = menu.buttons[i]
        if not btn then
            btn = CreateFrame("Button", nil, dContent)
            btn:SetHeight(itemHeight)
            btn:SetNormalFontObject("GameFontHighlightSmall")
            btn:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")

            local txt = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            txt:SetPoint("LEFT", btn, "LEFT", 4, 0)
            txt:SetPoint("RIGHT", btn, "RIGHT", -4, 0)
            txt:SetJustifyH("LEFT")
            btn.label = txt

            menu.buttons[i] = btn
        end

        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", dContent, "TOPLEFT", 2, yPos)
        btn:SetPoint("TOPRIGHT", dContent, "TOPRIGHT", -2, yPos)
        btn.label:SetText(opt.name)

        local currentVal = ForeverBoardDB and ForeverBoardDB[activeDropKey] or ""
        if currentVal == opt.id then
            btn.label:SetTextColor(1, 0.85, 0.2)
        else
            btn.label:SetTextColor(0.9, 0.9, 0.9)
        end

        btn:SetScript("OnClick", function()
            if ForeverBoardDB and activeDropKey then
                ForeverBoardDB[activeDropKey] = opt.id
                if FB.UpdateTriggerButtons then
                    FB:UpdateTriggerButtons()
                end
            end
            menu:Hide()
        end)

        btn:Show()
        yPos = yPos - itemHeight
    end

    for j = #options + 1, #menu.buttons do
        menu.buttons[j]:Hide()
    end

    local totalH = math.min(math.abs(yPos) + 8, 220)
    dContent:SetHeight(math.abs(yPos) + 8)
    menu:SetHeight(totalH)
    menu:Show()
end

-- Cambia la pestaña activa (Todos / Favoritos / Eventos)
function FB:SetTab(tab)
    currentTab = tab
    if dropDownMenu then dropDownMenu:Hide() end

    if tabAllBtn and tabFavBtn and tabTrigBtn then
        tabAllBtn:UnlockHighlight()
        tabFavBtn:UnlockHighlight()
        tabTrigBtn:UnlockHighlight()

        if currentTab == "ALL" then
            tabAllBtn:LockHighlight()
        elseif currentTab == "FAV" then
            tabFavBtn:LockHighlight()
        elseif currentTab == "TRIGGERS" then
            tabTrigBtn:LockHighlight()
        end
    end

    if currentTab == "TRIGGERS" then
        if scrollFrame then scrollFrame:Hide() end
        if searchBox then searchBox:Hide() end
        if triggerContent then triggerContent:Show() end
        if self.UpdateTriggerButtons then
            self:UpdateTriggerButtons()
        end
    else
        if triggerContent then triggerContent:Hide() end
        if scrollFrame then scrollFrame:Show() end
        if searchBox then searchBox:Show() end
        self:RefreshSoundList()
    end
end

-- ==========================================================
-- Rejilla Dinámica (Grid) Adaptativa para los sonidos
-- ==========================================================
function FB:RefreshSoundList()
    if not contentFrame or currentTab == "TRIGGERS" then return end

    local filter = ""
    if searchBox and searchBox.GetText then
        filter = strTrim(searchBox:GetText()):lower()
    end

    local sounds = ForeverBoard_Sounds or {}
    local availWidth = (scrollFrame and scrollFrame.GetWidth and scrollFrame:GetWidth()) or 340
    availWidth = math.max(availWidth - 26, 200)
    contentFrame:SetWidth(availWidth)

    -- Calcular número de columnas dinámico según el ancho de la ventana
    local colMin = 145
    local cols = math.floor(availWidth / colMin)
    if cols < 1 then cols = 1 end
    if cols > 5 then cols = 5 end

    local spacing = 6
    local tileWidth = math.floor((availWidth - ((cols - 1) * spacing)) / cols)
    local tileHeight = 36

    local visibleIdx = 0
    local favCount = 0

    for i, item in ipairs(sounds) do
        local tile = soundTiles[i]
        if tile then
            local isFav = self:IsFavorite(item.id)
            if isFav then favCount = favCount + 1 end

            local matchesTab = (currentTab == "ALL") or (currentTab == "FAV" and isFav)

            local matchesFilter = true
            if filter ~= "" then
                local nameMatch = item.name and item.name:lower():find(filter, 1, true)
                local idMatch = item.id and item.id:lower():find(filter, 1, true)
                local descMatch = item.desc and item.desc:lower():find(filter, 1, true)
                matchesFilter = (nameMatch or idMatch or descMatch) ~= nil
            end

            if matchesTab and matchesFilter then
                local col = visibleIdx % cols
                local row = math.floor(visibleIdx / cols)

                local posX = col * (tileWidth + spacing)
                local posY = - (row * (tileHeight + spacing)) - 4

                tile:ClearAllPoints()
                tile:SetPoint("TOPLEFT", contentFrame, "TOPLEFT", posX, posY)
                tile:SetSize(tileWidth, tileHeight)

                -- Actualizar estrella de favorito
                if isFav then
                    tile.star.icon:SetVertexColor(1, 0.85, 0.1, 1)
                else
                    tile.star.icon:SetVertexColor(0.28, 0.28, 0.32, 0.6)
                end

                tile:Show()
                visibleIdx = visibleIdx + 1
            else
                tile:Hide()
            end
        end
    end

    local totalRows = math.ceil(visibleIdx / cols)
    local totalHeight = (totalRows * (tileHeight + spacing)) + 12
    contentFrame:SetHeight(math.max(totalHeight, 50))

    -- Actualizar contador inferior y pestañas
    if countLabel then
        countLabel:SetText(string.format("%d clips", visibleIdx))
    end
    if tabAllBtn then
        tabAllBtn:SetText(string.format("%s (%d)", L("TAB_ALL"), #sounds))
    end
    if tabFavBtn then
        tabFavBtn:SetText(string.format("%s (%d)", L("TAB_FAV"), favCount))
    end
end

function FB:CreateUI()
    if mainFrame then return mainFrame end

    -- Dimensiones iniciales estilo Discord Soundboard (más ancho y proporcionado)
    local defaultWidth = (ForeverBoardDB and ForeverBoardDB.width) or 370
    local defaultHeight = (ForeverBoardDB and ForeverBoardDB.height) or 440

    mainFrame = CreateFrame("Frame", "ForeverBoardFrame", UIParent)
    mainFrame:SetSize(defaultWidth, defaultHeight)
    if mainFrame.SetMinResize then
        mainFrame:SetMinResize(290, 320)
        mainFrame:SetMaxResize(850, 900)
    elseif mainFrame.SetResizeBounds then
        mainFrame:SetResizeBounds(290, 320, 850, 900)
    end
    mainFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    mainFrame:SetMovable(true)
    mainFrame:SetResizable(true)
    mainFrame:EnableMouse(true)
    mainFrame:SetClampedToScreen(true)

    -- Arrastrar ventana
    mainFrame:RegisterForDrag("LeftButton")
    mainFrame:SetScript("OnDragStart", function(self)
        if dropDownMenu then dropDownMenu:Hide() end
        self:StartMoving()
    end)
    mainFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, _, x, y = self:GetPoint()
        if ForeverBoardDB then
            ForeverBoardDB.point = point
            ForeverBoardDB.posX = x
            ForeverBoardDB.posY = y
        end
    end)

    -- Fondo estilizado con bordes finos de diálogo
    if mainFrame.SetBackdrop then
        mainFrame:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 16,
            insets = { left = 5, right = 5, top = 5, bottom = 5 }
        })
    else
        local bg = mainFrame:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints(true)
        bg:SetColorTexture(0.08, 0.08, 0.1, 0.94)
    end

    -- ==========================================
    -- Cabecera
    -- ==========================================
    local title = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 16, -12)
    title:SetText("|cff00ccffForeverBoard|r")

    -- Botón de cerrar
    local closeBtn = CreateFrame("Button", nil, mainFrame, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -4, -4)
    closeBtn:SetScript("OnClick", function()
        if dropDownMenu then dropDownMenu:Hide() end
        mainFrame:Hide()
    end)

    -- Botón de Mute rápido en la cabecera (derecha, junto a cerrar)
    muteBtn = CreateFrame("Button", "ForeverBoardMuteBtn", mainFrame, "UIPanelButtonTemplate")
    muteBtn:SetSize(76, 20)
    muteBtn:SetPoint("TOPRIGHT", closeBtn, "TOPLEFT", -2, -4)
    muteBtn:SetScript("OnClick", function()
        ForeverBoardDB.isMuted = not ForeverBoardDB.isMuted
        FB:UpdateMuteVisuals()
        local status = ForeverBoardDB.isMuted and L("SOUND_STATUS_MUTED") or L("SOUND_STATUS_ON")
        print(string.format(L("SOUND_MUTED_MSG"), status))
    end)
    muteBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(L("MUTE_TOOLTIP_TITLE"), 1, 1, 1)
        GameTooltip:AddLine(L("MUTE_TOOLTIP_DESC"), 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    muteBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Pestañas como píldoras de navegación
    tabAllBtn = CreateFrame("Button", "ForeverBoardTabAll", mainFrame, "UIPanelButtonTemplate")
    tabAllBtn:SetSize(80, 20)
    tabAllBtn:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 16, -38)
    tabAllBtn:SetText(L("TAB_ALL"))
    tabAllBtn:SetScript("OnClick", function()
        FB:SetTab("ALL")
    end)

    tabFavBtn = CreateFrame("Button", "ForeverBoardTabFav", mainFrame, "UIPanelButtonTemplate")
    tabFavBtn:SetSize(86, 20)
    tabFavBtn:SetPoint("LEFT", tabAllBtn, "RIGHT", 4, 0)
    tabFavBtn:SetText(L("TAB_FAV"))
    tabFavBtn:SetScript("OnClick", function()
        FB:SetTab("FAV")
    end)

    tabTrigBtn = CreateFrame("Button", "ForeverBoardTabTrig", mainFrame, "UIPanelButtonTemplate")
    tabTrigBtn:SetSize(72, 20)
    tabTrigBtn:SetPoint("LEFT", tabFavBtn, "RIGHT", 4, 0)
    tabTrigBtn:SetText(L("TAB_TRIGGERS"))
    tabTrigBtn:SetScript("OnClick", function()
        FB:SetTab("TRIGGERS")
    end)

    -- Caja de búsqueda debajo de las pestañas
    searchBox = CreateFrame("EditBox", "ForeverBoardSearchBox", mainFrame, "InputBoxTemplate")
    searchBox:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 22, -64)
    searchBox:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -22, -64)
    searchBox:SetHeight(20)
    searchBox:SetAutoFocus(false)
    searchBox:SetScript("OnTextChanged", function(self)
        FB:RefreshSoundList()
    end)
    searchBox:SetScript("OnEscapePressed", function(self)
        self:SetText("")
        self:ClearFocus()
    end)

    -- ==========================================
    -- Panel de Triggers Automáticos en Tarjetas
    -- ==========================================
    triggerContent = CreateFrame("Frame", "ForeverBoardTriggerContent", mainFrame)
    triggerContent:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 14, -64)
    triggerContent:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -14, 34)
    triggerContent:Hide()

    local trigTitle = triggerContent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    trigTitle:SetPoint("TOPLEFT", triggerContent, "TOPLEFT", 6, -2)
    trigTitle:SetText(L("TRIGGERS_TITLE"))

    -- Función auxiliar para crear tarjetas limpias de trigger
    local function CreateTriggerCard(parent, titleText, iconTexture, prevFrame, dbCheckKey, dbSoundKey, triggerType)
        local card = CreateFrame("Frame", nil, parent)
        card:SetHeight(46)
        card:SetPoint("TOPLEFT", prevFrame, "BOTTOMLEFT", 0, -6)
        card:SetPoint("RIGHT", parent, "RIGHT", -6, 0)

        -- Fondo de tarjeta
        local cbg = card:CreateTexture(nil, "BACKGROUND")
        cbg:SetAllPoints(true)
        cbg:SetColorTexture(0.12, 0.12, 0.16, 0.75)

        -- Icono del evento
        local cIcon = card:CreateTexture(nil, "ARTWORK")
        cIcon:SetSize(28, 28)
        cIcon:SetPoint("LEFT", card, "LEFT", 8, 0)
        cIcon:SetTexture(iconTexture)

        -- Checkbox
        local chk = CreateFrame("CheckButton", nil, card, "UICheckButtonTemplate")
        chk:SetSize(20, 20)
        chk:SetPoint("LEFT", cIcon, "RIGHT", 6, 0)
        chk:SetChecked(ForeverBoardDB and ForeverBoardDB[dbCheckKey])
        chk:SetScript("OnClick", function(self)
            ForeverBoardDB[dbCheckKey] = self:GetChecked()
        end)

        -- Título del evento
        local lbl = card:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        lbl:SetPoint("LEFT", chk, "RIGHT", 4, 0)
        lbl:SetText(titleText)

        -- Botón desplegable de sonido
        local btn = CreateFrame("Button", nil, card, "UIPanelButtonTemplate")
        btn:SetSize(140, 20)
        btn:SetPoint("RIGHT", card, "RIGHT", -8, 0)
        btn:SetScript("OnClick", function(self)
            FB:OpenSoundDropDown(self, dbSoundKey, triggerType)
        end)

        return card, chk, btn
    end

    local cardLevel, chkLevel, btnSoundLevel = CreateTriggerCard(
        triggerContent,
        L("TRIG_LEVEL_TITLE"),
        "Interface\\Icons\\Spell_Holy_PrayerOfFortitude",
        trigTitle,
        "triggerLevelUp",
        "triggerLevelUpSound",
        "levelUp"
    )

    local cardBoss, chkBoss, btnSoundBoss = CreateTriggerCard(
        triggerContent,
        L("TRIG_BOSS_TITLE"),
        "Interface\\Icons\\INV_Misc_Head_Dragon_01",
        cardLevel,
        "triggerBossKill",
        "triggerBossKillSound",
        "bossKill"
    )

    local cardDead, chkDead, btnSoundDead = CreateTriggerCard(
        triggerContent,
        L("TRIG_DEAD_TITLE"),
        "Interface\\Icons\\Ability_Creature_Cursed_02",
        cardBoss,
        "triggerDeath",
        "triggerDeathSound",
        "death"
    )

    function FB:UpdateTriggerButtons()
        if btnSoundLevel and ForeverBoardDB then
            btnSoundLevel:SetText("> " .. FB:GetSoundDisplayName(ForeverBoardDB.triggerLevelUpSound, "levelUp"))
        end
        if btnSoundBoss and ForeverBoardDB then
            btnSoundBoss:SetText("> " .. FB:GetSoundDisplayName(ForeverBoardDB.triggerBossKillSound, "bossKill"))
        end
        if btnSoundDead and ForeverBoardDB then
            btnSoundDead:SetText("> " .. FB:GetSoundDisplayName(ForeverBoardDB.triggerDeathSound, "death"))
        end
    end

    -- Nota explicativa
    local note = triggerContent:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    note:SetPoint("TOPLEFT", cardDead, "BOTTOMLEFT", 4, -12)
    note:SetPoint("RIGHT", triggerContent, "RIGHT", -6, 0)
    note:SetJustifyH("LEFT")
    note:SetText(L("TRIGGERS_NOTE"))

    -- ==========================================
    -- Contenedor con Scroll para la Rejilla de Botones
    -- ==========================================
    scrollFrame = CreateFrame("ScrollFrame", "ForeverBoardScrollFrame", mainFrame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", searchBox, "BOTTOMLEFT", -6, -8)
    scrollFrame:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -28, 32)

    contentFrame = CreateFrame("Frame", nil, scrollFrame)
    contentFrame:SetSize(280, 1)
    scrollFrame:SetScrollChild(contentFrame)

    -- Manejar redimensionamiento dinámico de la rejilla
    scrollFrame:SetScript("OnSizeChanged", function(self, width)
        if contentFrame and width and width > 50 then
            FB:RefreshSoundList()
        end
    end)

    -- Generar Tarjetas / Tiles de sonido estilo Discord
    local sounds = ForeverBoard_Sounds or {}

    for i, item in ipairs(sounds) do
        -- Contenedor Tile del botón
        local tile = CreateFrame("Button", "ForeverBoardTile_" .. item.id, contentFrame)
        tile:SetNormalFontObject("GameFontHighlightSmall")

        -- Fondo del Tile
        local tbg = tile:CreateTexture(nil, "BACKGROUND")
        tbg:SetAllPoints(true)
        tbg:SetColorTexture(0.14, 0.14, 0.19, 0.85)
        tile.bg = tbg

        -- Borde resaltado al pasar el ratón (Hover)
        local hl = tile:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints(true)
        hl:SetColorTexture(0.25, 0.45, 0.85, 0.3)

        -- Icono del sonido a la izquierda
        local icon = tile:CreateTexture(nil, "ARTWORK")
        icon:SetSize(24, 24)
        icon:SetPoint("LEFT", tile, "LEFT", 6, 0)
        icon:SetTexture(GetSoundIcon(item))
        icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) -- Recorte suave de bordes de icono WoW
        tile.icon = icon

        -- Botón estrella de favoritos en la esquina superior derecha
        local star = CreateFrame("Button", nil, tile)
        star:SetSize(18, 18)
        star:SetPoint("TOPRIGHT", tile, "TOPRIGHT", -2, -2)

        local starIcon = star:CreateTexture(nil, "OVERLAY")
        starIcon:SetSize(14, 14)
        starIcon:SetPoint("CENTER", star, "CENTER", 0, 0)
        starIcon:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_1")
        star.icon = starIcon

        star:SetScript("OnClick", function()
            FB:ToggleFavorite(item.id)
        end)
        star:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            if FB:IsFavorite(item.id) then
                GameTooltip:AddLine(L("FAV_REMOVE_TOOLTIP"), 1, 0.3, 0.3)
            else
                GameTooltip:AddLine(L("FAV_ADD_TOOLTIP"), 1, 0.85, 0.2)
            end
            GameTooltip:Show()
        end)
        star:SetScript("OnLeave", function() GameTooltip:Hide() end)
        tile.star = star

        -- Texto del sonido centrado / ajustado al espacio
        local label = tile:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        label:SetPoint("LEFT", icon, "RIGHT", 6, 0)
        label:SetPoint("RIGHT", star, "LEFT", -2, 0)
        label:SetJustifyH("LEFT")
        label:SetWordWrap(false)
        label:SetText(item.name)
        tile.label = label

        -- Click: disparar sonido local y en red
        tile:SetScript("OnClick", function()
            FB:TriggerSound(item.id)
        end)

        -- Tooltip completo
        tile:SetScript("OnEnter", function(self)
            self.bg:SetColorTexture(0.20, 0.22, 0.28, 0.95)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(item.name, 1, 0.85, 0.2)
            if item.desc and item.desc ~= "" then
                GameTooltip:AddLine(item.desc, 0.8, 0.8, 0.8, true)
            end
            local favHint = FB:IsFavorite(item.id) and L("FAV_IN") or L("FAV_ADD_HINT")
            GameTooltip:AddLine(favHint, 0.8, 0.8, 0.8)
            GameTooltip:AddLine(string.format(L("CMD_HINT"), item.id), 0.5, 0.5, 0.5)
            GameTooltip:Show()
        end)

        tile:SetScript("OnLeave", function(self)
            self.bg:SetColorTexture(0.14, 0.14, 0.19, 0.85)
            GameTooltip:Hide()
        end)

        soundTiles[i] = tile
    end

    -- ==========================================
    -- Barra Inferior de Control
    -- ==========================================
    combatCheck = CreateFrame("CheckButton", "ForeverBoardCombatCheck", mainFrame, "UICheckButtonTemplate")
    combatCheck:SetSize(20, 20)
    combatCheck:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 10, 6)
    combatCheck:SetChecked(ForeverBoardDB and ForeverBoardDB.muteInCombat)
    combatCheck:SetScript("OnClick", function(self)
        ForeverBoardDB.muteInCombat = self:GetChecked()
    end)

    local combatLabel = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    combatLabel:SetPoint("LEFT", combatCheck, "RIGHT", 2, 0)
    combatLabel:SetText(L("MUTE_IN_COMBAT"))

    -- Contador de clips en el centro de la barra inferior
    countLabel = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    countLabel:SetPoint("CENTER", mainFrame, "BOTTOM", 0, 16)
    countLabel:SetText(string.format("%d clips", #sounds))

    -- Selector de canal de audio a la derecha
    channelBtn = CreateFrame("Button", "ForeverBoardChannelBtn", mainFrame, "UIPanelButtonTemplate")
    channelBtn:SetSize(105, 18)
    channelBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -22, 7)
    channelBtn:SetScript("OnClick", function()
        FB:CycleSoundChannel()
    end)
    channelBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(L("CHANNEL_TOOLTIP_TITLE"), 1, 1, 1)
        GameTooltip:AddLine(L("CHANNEL_TOOLTIP_DESC"), 0.8, 0.8, 0.8, true)
        GameTooltip:AddLine(L("CHANNEL_TOOLTIP_MASTER"), 0.5, 0.8, 1, true)
        GameTooltip:Show()
    end)
    channelBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Pestaña de redimensionamiento (Resize Grip)
    local resizeGrip = CreateFrame("Button", nil, mainFrame)
    resizeGrip:SetSize(16, 16)
    resizeGrip:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -2, 2)
    resizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeGrip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")

    resizeGrip:SetScript("OnMouseDown", function()
        if dropDownMenu then dropDownMenu:Hide() end
        mainFrame:StartSizing("BOTTOMRIGHT")
    end)
    resizeGrip:SetScript("OnMouseUp", function()
        mainFrame:StopMovingOrSizing()
        local w, h = mainFrame:GetSize()
        if ForeverBoardDB then
            ForeverBoardDB.width = w
            ForeverBoardDB.height = h
        end
        FB:RefreshSoundList()
    end)

    mainFrame:SetScript("OnSizeChanged", function(self, w, h)
        if scrollFrame and contentFrame then
            FB:RefreshSoundList()
        end
    end)

    -- Restaurar posición guardada
    if ForeverBoardDB and ForeverBoardDB.posX and ForeverBoardDB.posY then
        mainFrame:ClearAllPoints()
        mainFrame:SetPoint(ForeverBoardDB.point or "CENTER", UIParent, ForeverBoardDB.point or "CENTER", ForeverBoardDB.posX, ForeverBoardDB.posY)
    end

    FB:UpdateMuteVisuals()
    FB:UpdateChannelVisuals()
    FB:UpdateTriggerButtons()
    FB:SetTab("ALL")

    mainFrame:Hide()
    return mainFrame
end

function FB:ToggleUI()
    local ok, err = pcall(function()
        local frame = self:CreateUI()
        if frame:IsShown() then
            if dropDownMenu then dropDownMenu:Hide() end
            frame:Hide()
        else
            frame:Show()
            if searchBox then
                searchBox:SetText("")
            end
            FB:UpdateMuteVisuals()
            FB:UpdateChannelVisuals()
            FB:RefreshSoundList()
        end
    end)

    if not ok then
        print("|cff00ccff[ForeverBoard ERROR]|r " .. tostring(err))
    end
end

-- ==========================================================
-- Botón circular en el Minimapa
-- ==========================================================
local minimapBtn = nil

function FB:UpdateMinimapPosition()
    if not minimapBtn then return end
    local angle = (ForeverBoardDB and ForeverBoardDB.minimapPos) or 45
    local rad = math.rad(angle)
    local radius = 103
    local x = math.cos(rad) * radius
    local y = math.sin(rad) * radius
    minimapBtn:ClearAllPoints()
    minimapBtn:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

function FB:CreateMinimapButton()
    if minimapBtn then return minimapBtn end

    minimapBtn = CreateFrame("Button", "ForeverBoardMinimapButton", Minimap)
    minimapBtn:SetSize(33, 33)
    minimapBtn:SetFrameStrata("MEDIUM")
    minimapBtn:SetFrameLevel((Minimap:GetFrameLevel() or 5) + 5)
    minimapBtn:EnableMouse(true)
    minimapBtn:SetMovable(true)
    minimapBtn:RegisterForClicks("AnyUp")

    -- Icono interior
    local icon = minimapBtn:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(21, 21)
    icon:SetPoint("CENTER", minimapBtn, "CENTER", 0, 0)
    icon:SetTexture("Interface\\Icons\\Spell_ChargePositive")

    -- Borde circular estándar de Blizzard
    local border = minimapBtn:CreateTexture(nil, "OVERLAY")
    border:SetSize(56, 56)
    border:SetPoint("TOPLEFT", minimapBtn, "TOPLEFT", 0, 0)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

    minimapBtn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    -- Mover alrededor del minimapa con Clic Derecho
    minimapBtn:RegisterForDrag("RightButton")
    minimapBtn:SetScript("OnDragStart", function(self)
        self.isDragging = true
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local px, py = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            px, py = px / scale, py / scale
            local angle = math.deg(math.atan2(py - my, px - mx))
            if angle < 0 then angle = angle + 360 end
            if ForeverBoardDB then
                ForeverBoardDB.minimapPos = angle
            end
            FB:UpdateMinimapPosition()
        end)
    end)

    minimapBtn:SetScript("OnDragStop", function(self)
        self.isDragging = false
        self:SetScript("OnUpdate", nil)
    end)

    -- Clic: Abrir/Cerrar SoundBoard
    minimapBtn:SetScript("OnClick", function(self, button)
        if button == "LeftButton" then
            FB:ToggleUI()
        end
    end)

    -- Tooltip
    minimapBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cff00ccffForeverBoard|r", 1, 1, 1)
        GameTooltip:AddLine(L("MINIMAP_CLICK_HINT"), 0.8, 0.8, 0.8)
        GameTooltip:AddLine(L("MINIMAP_DRAG_HINT"), 0.5, 0.8, 1)
        local status = (ForeverBoardDB and ForeverBoardDB.isMuted) and L("SOUND_STATUS_MUTED") or L("SOUND_STATUS_ON")
        local ch = (ForeverBoardDB and ForeverBoardDB.soundChannel) or "Master"
        GameTooltip:AddLine(string.format(L("MINIMAP_AUDIO_STATE"), status), 0.7, 0.7, 0.7)
        GameTooltip:AddLine(string.format(L("MINIMAP_CHANNEL"), ch), 0.6, 0.8, 1)
        GameTooltip:Show()
    end)
    minimapBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    FB:UpdateMinimapPosition()
    return minimapBtn
end
